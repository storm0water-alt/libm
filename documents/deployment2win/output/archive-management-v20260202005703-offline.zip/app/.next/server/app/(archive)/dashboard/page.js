(()=>{var e={};e.id=3119,e.ids=[3119],e.modules={96330:e=>{"use strict";e.exports=require("@prisma/client")},5486:e=>{"use strict";e.exports=require("bcrypt")},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},19121:e=>{"use strict";e.exports=require("next/dist/server/app-render/action-async-storage.external.js")},3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},55511:e=>{"use strict";e.exports=require("crypto")},33873:e=>{"use strict";e.exports=require("path")},79551:e=>{"use strict";e.exports=require("url")},27363:(e,t,a)=>{"use strict";a.r(t),a.d(t,{GlobalError:()=>n.a,__next_app__:()=>p,pages:()=>o,routeModule:()=>h,tree:()=>c});var s=a(70260),i=a(28203),r=a(25155),n=a.n(r),l=a(67292),d={};for(let e in l)0>["default","tree","pages","GlobalError","__next_app__","routeModule"].indexOf(e)&&(d[e]=()=>l[e]);a.d(t,d);let c=["",{children:["(archive)",{children:["dashboard",{children:["__PAGE__",{},{page:[()=>Promise.resolve().then(a.bind(a,4745)),"/Users/jiaomingshi/IdeaProjects/libm/archive-management/app/(archive)/dashboard/page.tsx"]}]},{}]},{layout:[()=>Promise.resolve().then(a.bind(a,55965)),"/Users/jiaomingshi/IdeaProjects/libm/archive-management/app/(archive)/layout.tsx"],"not-found":[()=>Promise.resolve().then(a.t.bind(a,19937,23)),"next/dist/client/components/not-found-error"],forbidden:[()=>Promise.resolve().then(a.t.bind(a,69116,23)),"next/dist/client/components/forbidden-error"],unauthorized:[()=>Promise.resolve().then(a.t.bind(a,41485,23)),"next/dist/client/components/unauthorized-error"],metadata:{icon:[async e=>(await Promise.resolve().then(a.bind(a,46055))).default(e)],apple:[],openGraph:[],twitter:[],manifest:void 0}}]},{layout:[()=>Promise.resolve().then(a.bind(a,19611)),"/Users/jiaomingshi/IdeaProjects/libm/archive-management/app/layout.tsx"],error:[()=>Promise.resolve().then(a.bind(a,72627)),"/Users/jiaomingshi/IdeaProjects/libm/archive-management/app/error.tsx"],"not-found":[()=>Promise.resolve().then(a.t.bind(a,19937,23)),"next/dist/client/components/not-found-error"],forbidden:[()=>Promise.resolve().then(a.t.bind(a,69116,23)),"next/dist/client/components/forbidden-error"],unauthorized:[()=>Promise.resolve().then(a.t.bind(a,41485,23)),"next/dist/client/components/unauthorized-error"],metadata:{icon:[async e=>(await Promise.resolve().then(a.bind(a,46055))).default(e)],apple:[],openGraph:[],twitter:[],manifest:void 0}}],o=["/Users/jiaomingshi/IdeaProjects/libm/archive-management/app/(archive)/dashboard/page.tsx"],p={require:a,loadChunk:()=>Promise.resolve()},h=new s.AppPageRouteModule({definition:{kind:i.RouteKind.APP_PAGE,page:"/(archive)/dashboard/page",pathname:"/dashboard",bundlePath:"",filename:"",appPaths:[]},userland:{loaderTree:c}})},24288:(e,t,a)=>{Promise.resolve().then(a.bind(a,4745))},11136:(e,t,a)=>{Promise.resolve().then(a.bind(a,65697))},65697:(e,t,a)=>{"use strict";a.r(t),a.d(t,{default:()=>v});var s=a(45512),i=a(58009),r=a(98805),n=a(79334),l=a(28531),d=a.n(l),c=a(97643),o=a(87021),p=a(86235),h=a(72744),m=a(16873),x=a(96331);let u=(0,x.A)("list",[["path",{d:"M3 5h.01",key:"18ugdj"}],["path",{d:"M3 12h.01",key:"nlz23k"}],["path",{d:"M3 19h.01",key:"noohij"}],["path",{d:"M8 5h13",key:"1pao27"}],["path",{d:"M8 12h13",key:"1za7za"}],["path",{d:"M8 19h13",key:"m83p4d"}]]);var g=a(61075);let b=(0,x.A)("activity",[["path",{d:"M22 12h-2.48a2 2 0 0 0-1.93 1.46l-2.35 8.36a.25.25 0 0 1-.48 0L9.24 2.18a.25.25 0 0 0-.48 0l-2.35 8.36A2 2 0 0 1 4.49 12H2",key:"169zse"}]]);var j=a(64977);let y=(0,x.A)("trending-up",[["path",{d:"M16 7h6v6",key:"box55l"}],["path",{d:"m22 7-8.5 8.5-5-5L2 17",key:"1t1m79"}]]),f=(0,x.A)("trending-down",[["path",{d:"M16 17h6v-6",key:"t6n2it"}],["path",{d:"m22 17-8.5-8.5-5 5L2 7",key:"x473p"}]]);function v(){let{data:e,status:t}=(0,r.wV)(),a=(0,n.useRouter)(),[l,x]=(0,i.useState)({totalArchives:0,todayOperations:0,activeUsers:0,archiveTrend:12.5,operationTrend:8.7,userTrend:5.2,licenseStatus:{valid:!0,expireTime:null}}),[y,f]=(0,i.useState)(!0),[v,k]=(0,i.useState)([]),[N,A]=(0,i.useState)([]),[z,P]=(0,i.useState)([]),q=[{title:"文件入库",icon:(0,s.jsx)(h.A,{size:24}),color:"success",path:"/import"},{title:"档案查询",icon:(0,s.jsx)(m.A,{size:24}),color:"warning",path:"/search"},{title:"操作日志",icon:(0,s.jsx)(u,{size:24}),color:"info",path:"/logs"}],M=e=>{a.push(e.path)};return"loading"===t||y?(0,s.jsx)("div",{className:"flex items-center justify-center min-h-screen",children:(0,s.jsx)(p.A,{className:"h-8 w-8 animate-spin text-gray-400"})}):(0,s.jsxs)("div",{className:"dashboard",children:[(0,s.jsx)("div",{className:"welcome-section",children:(0,s.jsx)(c.Zp,{className:"welcome-card",children:(0,s.jsxs)(c.Wu,{className:"welcome-content",children:[(0,s.jsxs)("div",{className:"welcome-info",children:[(0,s.jsxs)("h2",{className:"welcome-title",children:["欢迎回来，",e?.user?.username||"用户","！"]}),(0,s.jsxs)("p",{className:"welcome-subtitle",children:["今天是 ",(()=>{let e=new Date,t=e.getFullYear(),a=String(e.getMonth()+1).padStart(2,"0"),s=String(e.getDate()).padStart(2,"0");return`${t}年${a}月${s}日`})(),"，祝您工作愉快！"]})]}),(0,s.jsx)("div",{className:"welcome-actions",children:(0,s.jsxs)(o.$,{type:"button",onClick:()=>M(q[0]),children:[(0,s.jsx)(h.A,{className:"mr-2 h-4 w-4"}),"文件入库"]})})]})})}),(0,s.jsx)("div",{className:"stats-section",children:(0,s.jsxs)("div",{className:"stats-grid",children:[(0,s.jsx)(w,{title:"档案总数",value:l.totalArchives.toLocaleString(),icon:(0,s.jsx)(g.A,{size:24}),color:"primary",trend:l.archiveTrend,loading:y}),(0,s.jsx)(w,{title:"今日操作次数",value:l.todayOperations.toString(),icon:(0,s.jsx)(b,{size:24}),color:"success",trend:l.operationTrend,loading:y}),(0,s.jsx)(w,{title:"活跃用户数",value:l.activeUsers.toString(),icon:(0,s.jsx)(j.A,{size:24}),color:"info",trend:l.userTrend,loading:y})]})}),(0,s.jsxs)("div",{className:"main-content",children:[(0,s.jsxs)("div",{className:"content-left",children:[(0,s.jsxs)(c.Zp,{className:"quick-actions-card",children:[(0,s.jsx)(c.aR,{children:(0,s.jsxs)("div",{className:"card-header",children:[(0,s.jsx)("h3",{children:"快捷操作"}),(0,s.jsx)(o.$,{variant:"link",className:"text-purple-600",children:"更多"})]})}),(0,s.jsx)(c.Wu,{children:(0,s.jsx)("div",{className:"quick-actions-grid",children:q.map(e=>(0,s.jsxs)("div",{className:`quick-action-item quick-action-${e.color}`,onClick:()=>M(e),children:[e.icon,(0,s.jsx)("span",{children:e.title})]},e.title))})})]}),(0,s.jsxs)(c.Zp,{className:"recent-archives-card",children:[(0,s.jsx)(c.aR,{children:(0,s.jsxs)("div",{className:"card-header",children:[(0,s.jsx)("h3",{children:"最近档案"}),(0,s.jsx)(o.$,{variant:"link",className:"text-purple-600",asChild:!0,children:(0,s.jsx)(d(),{href:"/archives",children:"查看全部"})})]})}),(0,s.jsx)(c.Wu,{children:v.length>0?(0,s.jsx)("div",{className:"recent-list",children:v.map(e=>(0,s.jsxs)("div",{className:"recent-item",onClick:()=>a.push(`/archives/${e.id}`),children:[(0,s.jsxs)("div",{className:"item-info",children:[(0,s.jsx)("div",{className:"item-title",children:e.title}),(0,s.jsxs)("div",{className:"item-meta",children:[(0,s.jsx)("span",{className:"item-id",children:e.meta}),(0,s.jsx)("span",{className:"item-time",children:e.time})]})]}),(0,s.jsx)(g.A,{className:"item-icon",size:16})]},e.id))}):(0,s.jsx)("p",{className:"text-sm text-gray-500 text-center py-4",children:"暂无数据"})})]})]}),(0,s.jsxs)("div",{className:"content-right",children:[(0,s.jsxs)(c.Zp,{className:"chart-card",children:[(0,s.jsx)(c.aR,{children:(0,s.jsx)("h3",{children:"保管期限分布"})}),(0,s.jsx)(c.Wu,{children:(0,s.jsx)("div",{className:"chart-container",children:z.length>0?(0,s.jsx)("div",{className:"type-distribution",children:z.map((e,t)=>{let a=["#3b82f6","#10b981","#f59e0b","#8b5cf6","#6b7280"],i=a[t%a.length];return(0,s.jsxs)("div",{className:"type-item",children:[(0,s.jsx)("div",{className:"type-color",style:{backgroundColor:i}}),(0,s.jsx)("span",{className:"type-name",children:e.name}),(0,s.jsx)("span",{className:"type-value",children:e.value})]},e.name)})}):(0,s.jsx)("p",{className:"text-sm text-gray-500 text-center py-4",children:"暂无数据"})})})]}),(0,s.jsxs)(c.Zp,{className:"recent-logs-card",children:[(0,s.jsx)(c.aR,{children:(0,s.jsxs)("div",{className:"card-header",children:[(0,s.jsx)("h3",{children:"最近操作"}),(0,s.jsx)(o.$,{variant:"link",className:"text-purple-600",asChild:!0,children:(0,s.jsx)(d(),{href:"/logs",children:"查看全部"})})]})}),(0,s.jsx)(c.Wu,{children:N.length>0?(0,s.jsx)("div",{className:"recent-list",children:N.map(e=>(0,s.jsxs)("div",{className:"recent-item",onClick:()=>a.push("/logs"),children:[(0,s.jsxs)("div",{className:"item-info",children:[(0,s.jsx)("div",{className:"item-title",children:e.title}),(0,s.jsxs)("div",{className:"item-meta",children:[(0,s.jsx)("span",{className:"item-target",children:e.meta}),(0,s.jsx)("span",{className:"item-time",children:e.time})]})]}),(0,s.jsx)(b,{className:"item-icon",size:16})]},e.id))}):(0,s.jsx)("p",{className:"text-sm text-gray-500 text-center py-4",children:"暂无数据"})})]})]})]}),(0,s.jsxs)(c.Zp,{className:"trend-card",children:[(0,s.jsx)(c.aR,{children:(0,s.jsx)("h3",{children:"本周操作趋势"})}),(0,s.jsx)(c.Wu,{children:(0,s.jsx)("div",{className:"trend-chart",children:(0,s.jsx)("div",{className:"trend-bars",children:[{day:"周一",operations:65},{day:"周二",operations:89},{day:"周三",operations:72},{day:"周四",operations:95},{day:"周五",operations:108},{day:"周六",operations:45},{day:"周日",operations:58}].map(e=>(0,s.jsxs)("div",{className:"trend-bar",children:[(0,s.jsx)("div",{className:"bar-wrapper",children:(0,s.jsx)("div",{className:"bar",style:{height:`${e.operations/150*100}%`}})}),(0,s.jsx)("span",{className:"bar-label",children:e.day}),(0,s.jsx)("span",{className:"bar-value",children:e.operations})]},e.day))})})})]}),(0,s.jsx)("style",{children:`
        .dashboard {
          padding: 0;
          height: 100%;
          width: 100%;
          display: flex;
          flex-direction: column;
          min-height: 100%;
        }

        .welcome-section {
          margin-bottom: 24px;
        }

        .welcome-card {
          border-radius: 16px;
          background: linear-gradient(135deg, #667eea, #764ba2);
          border: none;
        }

        .welcome-content {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 24px;
          padding: 32px;
        }

        .welcome-info {
          flex: 1;
        }

        .welcome-title {
          font-size: 30px;
          font-weight: 700;
          margin: 0 0 8px 0;
          color: white;
        }

        .welcome-subtitle {
          font-size: 16px;
          margin: 0;
          opacity: 0.9;
          color: white;
        }

        .welcome-actions {
          display: flex;
          gap: 12px;
          flex-shrink: 0;
        }

        .welcome-button-success {
          background: rgba(255, 255, 255, 0.2);
          border: 1px solid rgba(255, 255, 255, 0.3);
          color: white;
        }

        .welcome-button-success:hover {
          background: rgba(255, 255, 255, 0.3);
        }

        .stats-section {
          margin-bottom: 24px;
        }

        .stats-grid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
          gap: 20px;
        }

        .main-content {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 24px;
          margin-bottom: 24px;
        }

        .card-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
        }

        .card-header h3 {
          margin: 0;
          font-size: 18px;
          font-weight: 600;
          color: #1a202c;
        }

        .quick-actions-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 12px;
        }

        .quick-action-item {
          display: flex;
          flex-direction: column;
          align-items: center;
          gap: 8px;
          padding: 20px;
          border-radius: 12px;
          cursor: pointer;
          transition: all 0.2s ease;
          color: white;
          font-weight: 500;
        }

        .quick-action-item:hover {
          transform: translateY(-2px);
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }

        .quick-action-primary {
          background: linear-gradient(135deg, #667eea, #764ba2);
        }

        .quick-action-success {
          background: linear-gradient(135deg, #48bb78, #34d399);
        }

        .quick-action-warning {
          background: linear-gradient(135deg, #ecc94b, #d69e2e);
        }

        .quick-action-info {
          background: linear-gradient(135deg, #4fd1c5, #38b2ac);
        }

        .recent-list {
          display: flex;
          flex-direction: column;
          gap: 12px;
        }

        .recent-item {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 12px;
          background: #f7fafc;
          border-radius: 8px;
          transition: all 0.2s ease;
          cursor: pointer;
        }

        .recent-item:hover {
          background: #edf2f7;
        }

        .item-info {
          flex: 1;
          min-width: 0;
        }

        .item-title {
          font-size: 14px;
          font-weight: 500;
          color: #1a202c;
          margin-bottom: 4px;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        .item-meta {
          display: flex;
          align-items: center;
          gap: 8px;
          font-size: 12px;
          color: #718096;
        }

        .item-id {
          background: #e2e8f0;
          padding: 2px 6px;
          border-radius: 3px;
          font-family: monospace;
        }

        .item-target {
          color: #4a5568;
          max-width: 150px;
          overflow: hidden;
          text-overflow: ellipsis;
          white-space: nowrap;
        }

        .item-icon {
          color: #a0aec0;
        }

        .chart-container {
          padding: 16px 0;
        }

        .type-distribution {
          display: flex;
          flex-direction: column;
          gap: 12px;
        }

        .type-item {
          display: flex;
          align-items: center;
          gap: 12px;
        }

        .type-color {
          width: 12px;
          height: 12px;
          border-radius: 3px;
          flex-shrink: 0;
        }

        .type-name {
          flex: 1;
          font-size: 14px;
          color: #1a202c;
        }

        .type-value {
          font-size: 14px;
          font-weight: 600;
          color: #1a202c;
        }

        .trend-card {
          margin-top: 24px;
        }

        .trend-chart {
          padding: 16px 0;
        }

        .trend-bars {
          display: flex;
          align-items: end;
          justify-content: space-between;
          gap: 16px;
          height: 200px;
        }

        .trend-bar {
          display: flex;
          flex-direction: column;
          align-items: center;
          flex: 1;
        }

        .bar-wrapper {
          flex: 1;
          width: 100%;
          display: flex;
          align-items: end;
          justify-content: center;
          margin-bottom: 8px;
        }

        .bar {
          width: 32px;
          background: linear-gradient(135deg, #667eea, #764ba2);
          border-radius: 4px 4px 0 0;
          min-height: 8px;
          transition: all 0.2s ease;
        }

        .trend-bar:hover .bar {
          transform: translateY(-2px);
          box-shadow: 0 4px 8px rgba(102, 126, 234, 0.3);
        }

        .bar-label {
          font-size: 12px;
          color: #718096;
          margin-bottom: 4px;
        }

        .bar-value {
          font-size: 12px;
          font-weight: 500;
          color: #1a202c;
        }

        /* 响应式适配 */
        @media (max-width: 1200px) {
          .main-content {
            grid-template-columns: 1fr;
            gap: 20px;
          }
        }

        @media (max-width: 768px) {
          .welcome-content {
            flex-direction: column;
            text-align: center;
          }

          .welcome-actions {
            width: 100%;
            justify-content: center;
          }

          .stats-grid {
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 16px;
          }

          .quick-actions-grid {
            grid-template-columns: 1fr;
            gap: 12px;
          }

          .trend-bars {
            gap: 8px;
            height: 150px;
          }

          .bar {
            width: 24px;
          }
        }

        @media (max-width: 480px) {
          .welcome-content {
            padding: 20px;
          }

          .welcome-title {
            font-size: 24px;
          }

          .stats-grid {
            grid-template-columns: 1fr;
          }

          .trend-bars {
            height: 120px;
          }

          .bar {
            width: 20px;
          }

          .bar-label,
          .bar-value {
            font-size: 10px;
          }
        }
      `})]})}function w({title:e,value:t,icon:a,color:i,trend:r,loading:n}){let l={primary:{bg:"bg-blue-50",text:"text-blue-600",trend:"text-blue-600"},success:{bg:"bg-green-50",text:"text-green-600",trend:"text-green-600"},warning:{bg:"bg-yellow-50",text:"text-yellow-600",trend:"text-yellow-600"},info:{bg:"bg-cyan-50",text:"text-cyan-600",trend:"text-cyan-600"}}[i];return(0,s.jsx)(c.Zp,{className:"stat-card cursor-pointer hover:shadow-md transition-shadow",children:(0,s.jsxs)(c.Wu,{className:"p-6",children:[(0,s.jsxs)("div",{className:"flex items-center justify-between mb-4",children:[(0,s.jsx)("div",{className:`p-3 rounded-lg ${l.bg}`,children:a}),(0,s.jsxs)("div",{className:`text-sm font-medium ${r>=0?l.trend:"text-red-600"}`,children:[r>=0?(0,s.jsx)(y,{size:16}):(0,s.jsx)(f,{size:16}),(0,s.jsxs)("span",{className:"ml-1",children:[Math.abs(r),"%"]})]})]}),(0,s.jsxs)("div",{className:"space-y-1",children:[(0,s.jsx)("p",{className:"text-sm text-gray-600",children:e}),(0,s.jsx)("p",{className:"text-2xl font-bold text-gray-900",children:n?"-":t})]})]})})}},52706:(e,t,a)=>{"use strict";a.d(t,{A:()=>s});let s=(0,a(96331).A)("chevron-left",[["path",{d:"m15 18-6-6 6-6",key:"1wnfg3"}]])},99905:(e,t,a)=>{"use strict";a.d(t,{A:()=>s});let s=(0,a(96331).A)("chevron-right",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]])},96795:(e,t,a)=>{"use strict";a.d(t,{A:()=>s});let s=(0,a(96331).A)("credit-card",[["rect",{width:"20",height:"14",x:"2",y:"5",rx:"2",key:"ynyp8z"}],["line",{x1:"2",x2:"22",y1:"10",y2:"10",key:"1b3vmo"}]])},61075:(e,t,a)=>{"use strict";a.d(t,{A:()=>s});let s=(0,a(96331).A)("file-text",[["path",{d:"M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",key:"1oefj6"}],["path",{d:"M14 2v5a1 1 0 0 0 1 1h5",key:"wfsgrz"}],["path",{d:"M10 9H8",key:"b1mrlr"}],["path",{d:"M16 13H8",key:"t4e002"}],["path",{d:"M16 17H8",key:"z1uh3a"}]])},6394:(e,t,a)=>{"use strict";a.d(t,{A:()=>s});let s=(0,a(96331).A)("folder-open",[["path",{d:"m6 14 1.5-2.9A2 2 0 0 1 9.24 10H20a2 2 0 0 1 1.94 2.5l-1.54 6a2 2 0 0 1-1.95 1.5H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H18a2 2 0 0 1 2 2v2",key:"usdka0"}]])},80574:(e,t,a)=>{"use strict";a.d(t,{A:()=>s});let s=(0,a(96331).A)("layout-dashboard",[["rect",{width:"7",height:"9",x:"3",y:"3",rx:"1",key:"10lvy0"}],["rect",{width:"7",height:"5",x:"14",y:"3",rx:"1",key:"16une8"}],["rect",{width:"7",height:"9",x:"14",y:"12",rx:"1",key:"1hutg5"}],["rect",{width:"7",height:"5",x:"3",y:"16",rx:"1",key:"ldoo1y"}]])},86235:(e,t,a)=>{"use strict";a.d(t,{A:()=>s});let s=(0,a(96331).A)("loader-circle",[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]])},30722:(e,t,a)=>{"use strict";a.d(t,{A:()=>s});let s=(0,a(96331).A)("log-out",[["path",{d:"m16 17 5-5-5-5",key:"1bji2h"}],["path",{d:"M21 12H9",key:"dn1m92"}],["path",{d:"M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4",key:"1uf3rs"}]])},16873:(e,t,a)=>{"use strict";a.d(t,{A:()=>s});let s=(0,a(96331).A)("search",[["path",{d:"m21 21-4.34-4.34",key:"14j7rj"}],["circle",{cx:"11",cy:"11",r:"8",key:"4ej97u"}]])},72744:(e,t,a)=>{"use strict";a.d(t,{A:()=>s});let s=(0,a(96331).A)("upload",[["path",{d:"M12 3v12",key:"1x0j5s"}],["path",{d:"m17 8-5-5-5 5",key:"7q97r8"}],["path",{d:"M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4",key:"ih7n3h"}]])},64977:(e,t,a)=>{"use strict";a.d(t,{A:()=>s});let s=(0,a(96331).A)("users",[["path",{d:"M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2",key:"1yyitq"}],["path",{d:"M16 3.128a4 4 0 0 1 0 7.744",key:"16gr8j"}],["path",{d:"M22 21v-2a4 4 0 0 0-3-3.87",key:"kshegd"}],["circle",{cx:"9",cy:"7",r:"4",key:"nufk8"}]])},4745:(e,t,a)=>{"use strict";a.r(t),a.d(t,{default:()=>s});let s=(0,a(46760).registerClientReference)(function(){throw Error("Attempted to call the default export of \"/Users/jiaomingshi/IdeaProjects/libm/archive-management/app/(archive)/dashboard/page.tsx\" from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"/Users/jiaomingshi/IdeaProjects/libm/archive-management/app/(archive)/dashboard/page.tsx","default")}};var t=require("../../../webpack-runtime.js");t.C(e);var a=e=>t(t.s=e),s=t.X(0,[638,9187,6936,5866,8077,7250,8531,8515],()=>a(27363));module.exports=s})();